package com.dailyimagerotator.utils

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Log
import androidx.exifinterface.media.ExifInterface
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID

object ImageUtils {

    private const val TAG = "ImageUtils"
    private const val MAX_DIMENSION = 1920   // px – max width or height after resize
    private const val JPEG_QUALITY = 80      // 0-100

    /**
     * Copies the image at [uri] into the app's private files directory,
     * compresses it, and returns the saved file path. Returns null on failure.
     */
    fun copyAndCompressImage(context: Context, uri: Uri): String? {
        return try {
            val inputStream = context.contentResolver.openInputStream(uri) ?: return null

            // Decode bounds first to decide whether we need to sub-sample
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeStream(inputStream, null, options)
            inputStream.close()

            val sampleSize = calculateInSampleSize(options, MAX_DIMENSION, MAX_DIMENSION)

            // Decode with sub-sampling
            val decodeStream = context.contentResolver.openInputStream(uri) ?: return null
            val decodedBitmap = BitmapFactory.decodeStream(
                decodeStream,
                null,
                BitmapFactory.Options().apply { inSampleSize = sampleSize }
            )
            decodeStream.close()

            if (decodedBitmap == null) {
                Log.e(TAG, "Failed to decode bitmap from $uri")
                return null
            }

            // Correct EXIF rotation
            val rotatedBitmap = correctExifRotation(context, uri, decodedBitmap)

            // Save to internal storage
            val dir = File(context.filesDir, "images").also { it.mkdirs() }
            val outFile = File(dir, "${UUID.randomUUID()}.jpg")
            FileOutputStream(outFile).use { fos ->
                rotatedBitmap.compress(Bitmap.CompressFormat.JPEG, JPEG_QUALITY, fos)
            }

            if (rotatedBitmap !== decodedBitmap) rotatedBitmap.recycle()
            decodedBitmap.recycle()

            outFile.absolutePath
        } catch (e: IOException) {
            Log.e(TAG, "copyAndCompressImage error", e)
            null
        }
    }

    private fun calculateInSampleSize(
        options: BitmapFactory.Options,
        reqWidth: Int,
        reqHeight: Int
    ): Int {
        val (height, width) = options.outHeight to options.outWidth
        var inSampleSize = 1
        if (height > reqHeight || width > reqWidth) {
            val halfHeight = height / 2
            val halfWidth = width / 2
            while (halfHeight / inSampleSize >= reqHeight && halfWidth / inSampleSize >= reqWidth) {
                inSampleSize *= 2
            }
        }
        return inSampleSize
    }

    private fun correctExifRotation(context: Context, uri: Uri, bitmap: Bitmap): Bitmap {
        return try {
            val stream = context.contentResolver.openInputStream(uri) ?: return bitmap
            val exif = ExifInterface(stream)
            stream.close()
            val orientation = exif.getAttributeInt(
                ExifInterface.TAG_ORIENTATION,
                ExifInterface.ORIENTATION_NORMAL
            )
            val rotation = when (orientation) {
                ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                else -> 0f
            }
            if (rotation == 0f) return bitmap
            val matrix = Matrix().apply { postRotate(rotation) }
            Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
        } catch (e: Exception) {
            Log.e(TAG, "EXIF correction failed", e)
            bitmap
        }
    }

    /** Deletes a compressed image file from internal storage. */
    fun deleteImage(path: String) {
        try {
            File(path).delete()
        } catch (e: Exception) {
            Log.e(TAG, "deleteImage error", e)
        }
    }
}
