package com.dailyimagerotator.ui

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.dailyimagerotator.R
import java.io.File

class ThumbnailAdapter(
    private val onItemClick: (Int) -> Unit,
    private val onDeleteClick: (Int) -> Unit
) : ListAdapter<String, ThumbnailAdapter.ThumbnailViewHolder>(DiffCallback) {

    private var selectedIndex: Int = 0

    fun setSelectedIndex(index: Int) {
        val old = selectedIndex
        selectedIndex = index
        if (old != index) {
            notifyItemChanged(old)
            notifyItemChanged(index)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ThumbnailViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_thumbnail, parent, false)
        return ThumbnailViewHolder(view)
    }

    override fun onBindViewHolder(holder: ThumbnailViewHolder, position: Int) {
        holder.bind(getItem(position), position == selectedIndex)
    }

    inner class ThumbnailViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val imageView: ImageView = itemView.findViewById(R.id.iv_thumbnail)
        private val deleteBtn: ImageButton = itemView.findViewById(R.id.btn_delete_thumb)
        private val selectedIndicator: View = itemView.findViewById(R.id.view_selected_indicator)

        fun bind(path: String, isSelected: Boolean) {
            Glide.with(imageView.context)
                .load(File(path))
                .centerCrop()
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .placeholder(R.drawable.ic_image_placeholder)
                .error(R.drawable.ic_image_placeholder)
                .into(imageView)

            selectedIndicator.visibility = if (isSelected) View.VISIBLE else View.GONE

            itemView.setOnClickListener { onItemClick(adapterPosition) }
            deleteBtn.setOnClickListener { onDeleteClick(adapterPosition) }
        }
    }

    object DiffCallback : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String) = oldItem == newItem
        override fun areContentsTheSame(oldItem: String, newItem: String) = oldItem == newItem
    }
}
