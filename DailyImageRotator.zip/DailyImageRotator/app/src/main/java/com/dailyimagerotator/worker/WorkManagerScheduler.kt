package com.dailyimagerotator.worker

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import java.util.concurrent.TimeUnit

object WorkManagerScheduler {

    private const val TAG = "WorkManagerScheduler"

    /**
     * Enqueues a periodic 24-hour rotation task.
     * Using KEEP policy so an existing enqueue is not disturbed on app re-launch.
     * On first call after install, pass [replaceExisting] = true to start fresh.
     */
    fun scheduleDailyRotation(context: Context, replaceExisting: Boolean = false) {
        val constraints = Constraints.Builder()
            // No network needed – fully offline
            .build()

        val workRequest = PeriodicWorkRequestBuilder<ImageRotationWorker>(
            24, TimeUnit.HOURS,
            // Flex period: worker may run in the last 1 hour of the 24h window
            1, TimeUnit.HOURS
        )
            .setConstraints(constraints)
            .build()

        val policy = if (replaceExisting)
            ExistingPeriodicWorkPolicy.CANCEL_AND_REENQUEUE
        else
            ExistingPeriodicWorkPolicy.KEEP

        WorkManager.getInstance(context)
            .enqueueUniquePeriodicWork(
                ImageRotationWorker.WORK_NAME,
                policy,
                workRequest
            )

        Log.d(TAG, "Daily rotation work scheduled (replace=$replaceExisting)")
    }

    fun cancelDailyRotation(context: Context) {
        WorkManager.getInstance(context).cancelUniqueWork(ImageRotationWorker.WORK_NAME)
        Log.d(TAG, "Daily rotation work cancelled")
    }
}
