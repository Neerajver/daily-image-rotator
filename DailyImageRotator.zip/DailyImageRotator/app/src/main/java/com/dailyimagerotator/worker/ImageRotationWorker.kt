package com.dailyimagerotator.worker

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.dailyimagerotator.R
import com.dailyimagerotator.data.ImagePreferences
import com.dailyimagerotator.ui.MainActivity

class ImageRotationWorker(
    private val context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    companion object {
        const val WORK_NAME = "daily_image_rotation"
        private const val TAG = "ImageRotationWorker"
        private const val CHANNEL_ID = "daily_image_rotator_channel"
        private const val NOTIFICATION_ID = 1001
    }

    override suspend fun doWork(): Result {
        Log.d(TAG, "doWork() called")
        return try {
            val prefs = ImagePreferences(context)
            val paths = prefs.getImagePaths()

            if (paths.isEmpty()) {
                Log.d(TAG, "No images to rotate.")
                return Result.success()
            }

            val newIndex = prefs.rotateToNext()
            Log.d(TAG, "Rotated to index $newIndex")

            showRotationNotification(newIndex, paths.size)
            Result.success()
        } catch (e: Exception) {
            Log.e(TAG, "Worker failed", e)
            Result.retry()
        }
    }

    private fun showRotationNotification(index: Int, total: Int) {
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE)
                as NotificationManager

        // Create channel (API 26+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Daily Image Rotator",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Notifies when the daily image changes"
            }
            manager.createNotificationChannel(channel)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        val pendingIntent = PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_image_notification)
            .setContentTitle("Daily Image Updated")
            .setContentText("Image ${index + 1} of $total is now displaying.")
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .build()

        manager.notify(NOTIFICATION_ID, notification)
    }
}
