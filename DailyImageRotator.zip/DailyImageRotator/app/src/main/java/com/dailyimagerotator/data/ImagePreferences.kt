package com.dailyimagerotator.data

import android.content.Context
import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

class ImagePreferences(context: Context) {

    companion object {
        private const val PREFS_NAME = "daily_image_rotator_prefs"
        private const val KEY_IMAGE_PATHS = "image_paths"
        private const val KEY_CURRENT_INDEX = "current_index"
        private const val KEY_LAST_ROTATION_TIME = "last_rotation_time"
        private const val ROTATION_INTERVAL_MS = 24 * 60 * 60 * 1000L // 24 hours
    }

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()

    // ── Image path list ──────────────────────────────────────────────────────

    fun saveImagePaths(paths: List<String>) {
        prefs.edit()
            .putString(KEY_IMAGE_PATHS, gson.toJson(paths))
            .apply()
    }

    fun getImagePaths(): List<String> {
        val json = prefs.getString(KEY_IMAGE_PATHS, null) ?: return emptyList()
        val type = object : TypeToken<List<String>>() {}.type
        return try {
            gson.fromJson(json, type) ?: emptyList()
        } catch (e: Exception) {
            emptyList()
        }
    }

    // ── Current index ────────────────────────────────────────────────────────

    fun saveCurrentIndex(index: Int) {
        prefs.edit().putInt(KEY_CURRENT_INDEX, index).apply()
    }

    fun getCurrentIndex(): Int = prefs.getInt(KEY_CURRENT_INDEX, 0)

    // ── Rotation timestamp ───────────────────────────────────────────────────

    fun saveLastRotationTime(timeMs: Long) {
        prefs.edit().putLong(KEY_LAST_ROTATION_TIME, timeMs).apply()
    }

    fun getLastRotationTime(): Long = prefs.getLong(KEY_LAST_ROTATION_TIME, 0L)

    // ── Rotation logic ───────────────────────────────────────────────────────

    /**
     * Returns true if 24 hours have elapsed since the last rotation.
     */
    fun shouldRotate(): Boolean {
        val last = getLastRotationTime()
        if (last == 0L) return false
        return System.currentTimeMillis() - last >= ROTATION_INTERVAL_MS
    }

    /**
     * Advances the index by one (wrapping) and records the current time.
     * Returns the new index.
     */
    fun rotateToNext(): Int {
        val paths = getImagePaths()
        if (paths.isEmpty()) return 0
        val next = (getCurrentIndex() + 1) % paths.size
        saveCurrentIndex(next)
        saveLastRotationTime(System.currentTimeMillis())
        return next
    }

    /**
     * Initialises rotation timestamp to now (called when first image set is uploaded).
     */
    fun initRotationTime() {
        if (getLastRotationTime() == 0L) {
            saveLastRotationTime(System.currentTimeMillis())
        }
    }

    fun clearAll() {
        prefs.edit().clear().apply()
    }
}
