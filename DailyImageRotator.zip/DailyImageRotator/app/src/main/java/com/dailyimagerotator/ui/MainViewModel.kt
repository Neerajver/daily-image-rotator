package com.dailyimagerotator.ui

import android.app.Application
import android.net.Uri
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.dailyimagerotator.data.ImagePreferences
import com.dailyimagerotator.utils.ImageUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = ImagePreferences(application)

    private val _imagePaths = MutableLiveData<List<String>>()
    val imagePaths: LiveData<List<String>> = _imagePaths

    private val _currentIndex = MutableLiveData<Int>()
    val currentIndex: LiveData<Int> = _currentIndex

    private val _isLoading = MutableLiveData(false)
    val isLoading: LiveData<Boolean> = _isLoading

    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> = _errorMessage

    init {
        loadImages()
    }

    // ── Load & startup rotation check ────────────────────────────────────────

    fun loadImages() {
        viewModelScope.launch {
            val paths = withContext(Dispatchers.IO) { prefs.getImagePaths() }

            // Check if 24 h have passed and advance if so
            val idx = withContext(Dispatchers.IO) {
                if (prefs.shouldRotate() && paths.isNotEmpty()) {
                    Log.d("MainViewModel", "24h elapsed – rotating to next image")
                    prefs.rotateToNext()
                } else {
                    prefs.getCurrentIndex()
                }
            }

            _imagePaths.value = paths
            _currentIndex.value = if (paths.isEmpty()) 0 else idx.coerceIn(0, paths.lastIndex)
        }
    }

    // ── Upload new images ────────────────────────────────────────────────────

    fun addImages(uris: List<Uri>) {
        if (uris.isEmpty()) return
        _isLoading.value = true

        viewModelScope.launch(Dispatchers.IO) {
            val existing = prefs.getImagePaths().toMutableList()
            var addedCount = 0

            for (uri in uris) {
                val path = ImageUtils.copyAndCompressImage(getApplication(), uri)
                if (path != null) {
                    existing.add(path)
                    addedCount++
                } else {
                    Log.e("MainViewModel", "Failed to process $uri")
                }
            }

            prefs.saveImagePaths(existing)
            prefs.initRotationTime()

            withContext(Dispatchers.Main) {
                _imagePaths.value = existing
                _isLoading.value = false
                if (addedCount < uris.size) {
                    _errorMessage.value = "Some images could not be imported."
                }
            }
        }
    }

    // ── Delete an image ──────────────────────────────────────────────────────

    fun deleteImage(index: Int) {
        val paths = _imagePaths.value?.toMutableList() ?: return
        if (index !in paths.indices) return

        viewModelScope.launch(Dispatchers.IO) {
            ImageUtils.deleteImage(paths[index])
            paths.removeAt(index)
            prefs.saveImagePaths(paths)

            val currentIdx = prefs.getCurrentIndex()
            val newIdx = when {
                paths.isEmpty() -> 0
                currentIdx >= paths.size -> 0
                else -> currentIdx
            }
            prefs.saveCurrentIndex(newIdx)

            withContext(Dispatchers.Main) {
                _imagePaths.value = paths
                _currentIndex.value = newIdx
            }
        }
    }

    // ── Manual index change (thumbnail tap) ─────────────────────────────────

    fun selectImage(index: Int) {
        val paths = _imagePaths.value ?: return
        if (index !in paths.indices) return
        prefs.saveCurrentIndex(index)
        _currentIndex.value = index
    }

    fun clearError() {
        _errorMessage.value = null
    }
}
