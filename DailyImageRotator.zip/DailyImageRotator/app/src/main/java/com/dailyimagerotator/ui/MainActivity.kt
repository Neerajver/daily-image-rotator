package com.dailyimagerotator.ui

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.dailyimagerotator.R
import com.dailyimagerotator.databinding.ActivityMainBinding
import com.dailyimagerotator.utils.PermissionUtils
import com.dailyimagerotator.worker.WorkManagerScheduler
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var thumbnailAdapter: ThumbnailAdapter

    // ── Permission launcher ──────────────────────────────────────────────────
    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { results ->
            if (results.values.all { it }) {
                openImagePicker()
            } else {
                Toast.makeText(
                    this,
                    "Storage permission is required to pick images.",
                    Toast.LENGTH_LONG
                ).show()
            }
        }

    // ── Image picker launcher ────────────────────────────────────────────────
    private val imagePickerLauncher =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) {
                // Take persistent URIs so we can read them in a background thread
                uris.forEach { uri ->
                    contentResolver.takePersistableUriPermission(
                        uri,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                }
                viewModel.addImages(uris)
            }
        }

    // ────────────────────────────────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        setupClickListeners()
        observeViewModel()

        // Schedule WorkManager (KEEP policy – won't restart an existing job)
        WorkManagerScheduler.scheduleDailyRotation(this)
    }

    override fun onResume() {
        super.onResume()
        // Re-check rotation every time the app comes to foreground
        viewModel.loadImages()
    }

    // ── Setup ────────────────────────────────────────────────────────────────

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = getString(R.string.app_name)
    }

    private fun setupRecyclerView() {
        thumbnailAdapter = ThumbnailAdapter(
            onItemClick = { index -> viewModel.selectImage(index) },
            onDeleteClick = { index -> confirmDelete(index) }
        )
        binding.rvThumbnails.apply {
            layoutManager = LinearLayoutManager(
                this@MainActivity,
                LinearLayoutManager.HORIZONTAL,
                false
            )
            adapter = thumbnailAdapter
        }
    }

    private fun setupClickListeners() {
        binding.fabUpload.setOnClickListener { checkPermissionAndPick() }
        binding.btnUploadEmpty.setOnClickListener { checkPermissionAndPick() }
        binding.ivMainImage.setOnClickListener {
            val paths = viewModel.imagePaths.value
            val idx = viewModel.currentIndex.value ?: 0
            if (!paths.isNullOrEmpty()) {
                openFullScreen(paths[idx])
            }
        }
    }

    // ── Observe ──────────────────────────────────────────────────────────────

    private fun observeViewModel() {
        viewModel.imagePaths.observe(this) { paths ->
            val isEmpty = paths.isEmpty()
            binding.layoutEmpty.visibility = if (isEmpty) View.VISIBLE else View.GONE
            binding.layoutImageViewer.visibility = if (isEmpty) View.GONE else View.VISIBLE

            thumbnailAdapter.submitList(paths.toList())

            // Refresh main image in case paths changed
            val idx = viewModel.currentIndex.value ?: 0
            if (!isEmpty) {
                showImage(paths[idx.coerceIn(0, paths.lastIndex)])
            }
        }

        viewModel.currentIndex.observe(this) { index ->
            val paths = viewModel.imagePaths.value ?: return@observe
            if (paths.isEmpty()) return@observe
            val safeIdx = index.coerceIn(0, paths.lastIndex)
            showImage(paths[safeIdx])
            thumbnailAdapter.setSelectedIndex(safeIdx)
            binding.rvThumbnails.scrollToPosition(safeIdx)
            updateImageCounter(safeIdx + 1, paths.size)
        }

        viewModel.isLoading.observe(this) { loading ->
            binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
            binding.fabUpload.isEnabled = !loading
        }

        viewModel.errorMessage.observe(this) { msg ->
            if (msg != null) {
                Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
                viewModel.clearError()
            }
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private fun showImage(path: String) {
        Glide.with(this)
            .load(File(path))
            .diskCacheStrategy(DiskCacheStrategy.ALL)
            .placeholder(R.drawable.ic_image_placeholder)
            .error(R.drawable.ic_image_placeholder)
            .into(binding.ivMainImage)
    }

    private fun updateImageCounter(current: Int, total: Int) {
        binding.tvImageCounter.text = getString(R.string.image_counter, current, total)
    }

    private fun openFullScreen(path: String) {
        val intent = Intent(this, FullScreenActivity::class.java)
            .putExtra(FullScreenActivity.EXTRA_IMAGE_PATH, path)
        startActivity(intent)
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }

    private fun checkPermissionAndPick() {
        if (PermissionUtils.hasReadImagePermission(this)) {
            openImagePicker()
        } else {
            permissionLauncher.launch(
                arrayOf(PermissionUtils.getReadImagePermission())
            )
        }
    }

    private fun openImagePicker() {
        imagePickerLauncher.launch(arrayOf("image/*"))
    }

    private fun confirmDelete(index: Int) {
        AlertDialog.Builder(this)
            .setTitle(R.string.delete_image_title)
            .setMessage(R.string.delete_image_message)
            .setPositiveButton(R.string.delete) { _, _ -> viewModel.deleteImage(index) }
            .setNegativeButton(R.string.cancel, null)
            .show()
    }
}
